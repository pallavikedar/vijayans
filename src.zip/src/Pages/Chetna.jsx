import React from "react";
import chetnaImg from "../Assets/Images/chetna-img1.ee1d0c124010e8fb972f.png";
import "../Style/chetna.css";
function Chetna() {
  return (
    <>
      <h1 className="chetna_heading">Welcome to Chetna's Page</h1>
      <div className="chetna_image_wrapper">
        <img src={chetnaImg} alt="Chetna" />
      </div>
      <div className="chetna_program_text">
        <h2>FEATURES OF THE PROGRAM</h2>
        <p>
          Special motivation, Solving various issues through group and
          individual counseling. Enhancing the imagination and empathy of
          children through meditation, helping learn self discipline in early
          life. Teaching the power of unity and oneness through counseling,
          helping children to bond with family and friends through yoga and its
          morals, relieving the stress through yoga and meditation, increasing
          concentration through pranayam and meditation, making children
          mentally physically and spiritually strong, special yoga sessions for
          health and mind development, sessions of parents and children for an
          improved relationship, helping children to lead a quality life and
          become a better person.
        </p>
      </div>
      <div className="chetna_program_list">
        <h2> PROBLEM FACED BY CHILDREN AND YOUNGSTER</h2>
        <ul>
          <li>No discipline in life.</li>
          <li>Do not listen to parents ‘advice.</li>
          <li>Disrespectful behavior to words parents.</li>
          <li>Failure in maintaining proper relationship with parents.</li>
          <li>Lack of love and understanding with family members.</li>
        </ul>
      </div>
    </>
  );
}

export default Chetna;
